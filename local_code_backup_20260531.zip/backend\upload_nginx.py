import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('47.83.0.101', username='root', password='WalletBackup2026!')

# 直接上传正确的配置文件
config = r'''server {
    listen 80;
    server_name chaseqiu.top www.chaseqiu.top ai656.top www.ai656.top api.ai656.top;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name chaseqiu.top www.chaseqiu.top ai656.top www.ai656.top api.ai656.top;

    ssl_certificate /etc/letsencrypt/live/chaseqiu.top/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chaseqiu.top/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location /666/ {
        root /opt/personal-website;
        index index.html;
        try_files $uri $uri/ /666/index.html;
    }

    location / {
        root /opt/personal-website/frontend;
        try_files $uri $uri/ /index.html;
    }

    location /webapp/ {
        root /opt/personal-website/frontend;
        index index.html;
        add_header Cross-Origin-Embedder-Policy "require-corp";
        add_header Cross-Origin-Opener-Policy "same-origin";

        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot|wasm|dart\.js)$ {
            expires -1;
            add_header Cache-Control "no-cache no-store must-revalidate";
            add_header Cross-Origin-Embedder-Policy "require-corp";
            add_header Cross-Origin-Opener-Policy "same-origin";
            try_files $uri =404;
        }

        location ~* \.html$ {
            add_header Cache-Control "no-cache no-store must-revalidate";
            add_header Cross-Origin-Embedder-Policy "require-corp";
            add_header Cross-Origin-Opener-Policy "same-origin";
        }

        try_files $uri $uri/ /webapp/index.html;
    }

    location /download/ {
        alias /opt/personal-website/frontend/download/;
        autoindex on;
        expires 1d;
        add_header Cache-Control "public";
    }

    location /api/wallet/backup {
        proxy_pass http://127.0.0.1:5001/api/wallet/backup;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/list {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/delete {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/restore {
        proxy_pass http://127.0.0.1:5002;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/create {
        proxy_pass http://127.0.0.1:5003/api/wallet/create;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/import/ {
        proxy_pass http://127.0.0.1:5003/api/wallet/import/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/balance {
        proxy_pass http://127.0.0.1:5003/api/wallet/balance;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/transfer {
        proxy_pass http://127.0.0.1:5003/api/wallet/transfer;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /api/wallet/estimate_fee {
        proxy_pass http://127.0.0.1:5003/api/wallet/estimate_fee;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /betting/ {
        proxy_pass http://127.0.0.1:5004/betting/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_http_version 1.1;
    }

    location /admin/ {
        proxy_pass http://127.0.0.1:5002/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /webhook/lemon-squeezy {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
'''

sftp = ssh.open_sftp()
sftp.put('/tmp/nginx_config', config)

# 上传配置文件
stdin, stdout, stderr = ssh.exec_command("cat > /etc/nginx/sites-enabled/personal-website << 'NGINXEOF'\n" + config + "\nNGINXEOF")
stdout.read()

print("测试配置...")
stdin, stdout, stderr = ssh.exec_command("nginx -t")
print(stdout.read().decode('utf-8'))
print(stderr.read().decode('utf-8'))

stdin, stdout, stderr = ssh.exec_command("nginx -s reload")
print("✅ Nginx已重载")

ssh.close()
